<?php

use App\Http\Livewire\Blog;
use App\Http\Livewire\Home;
use App\Http\Livewire\History;
use App\Http\Livewire\Checkout;
use App\Http\Livewire\Keranjang;
use App\Http\Livewire\PostDetail;
use App\Http\Livewire\Verifikasi;
use App\Http\Livewire\ProductLiga;
use App\Http\Livewire\PostCategory;
use App\Http\Livewire\ProductIndex;
use App\Http\Livewire\ProductDetail;
use Illuminate\Support\Facades\Route;


Route::middleware(['auth'])->group(function () {
    Route::get('/history', History::class)->name('history');
    Route::get('/checkout', Checkout::class)->name('checkout');
    Route::get('/verifikasi', Verifikasi::class)->name('verifikasi');
});

Route::middleware(['web'])->group(function () {

    Route::get('/', Home::class)->name('home');
    Route::get('/products', ProductIndex::class)->name('products');
    Route::get('/products/{slug}', ProductDetail::class)->name('products.detail');
    Route::get('/products/kategori/{slug}', ProductLiga::class)->name('products.liga');
    Route::get('/keranjang', Keranjang::class)->name('keranjang');
    // Blog
    Route::get('/blog', Blog::class)->name('blog');
    Route::get('/blog/kategori/{slug}', PostCategory::class)->name('postcategory');
    Route::get('/{slug}', PostDetail::class)->name('postdetail');
});
