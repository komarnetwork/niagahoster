<?php

use Illuminate\Support\Facades\{Route, Auth};

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::middleware(['role:admin'])->group(function () {
    Route::get('/dashboard', 'DashboardController@index')->name('dashboard');
    // CRUD Blog
    Route::get('/post/tampil_hapus', 'PostController@tampil_hapus')->name('post.tampil_hapus');
    Route::get('/post/restore/{id}', 'PostController@restore')->name('post.restore');
    Route::delete('/post/kill/{id}', 'PostController@kill')->name('post.kill');
    Route::resource('/post', 'PostController');
    Route::resource('/category', 'CategoryController');
    Route::resource('/tag', 'TagController');
    Route::resource('/user', 'UserController');

    // CRUD Ecommerce
    Route::resource('/kategori-product', 'KategoriProductController');
    Route::get('/productlist/tampil_hapus', 'ProductListController@tampil_hapus')->name('productlist.tampil_hapus');
    Route::get('/productlist/restore{id}', 'ProductListController@restore')->name('productlist.restore');
    Route::delete('/productlist/kill/{id}', 'ProductListController@kill')->name('productlist.kill');
    Route::resource('/productlist', 'ProductListController');
    Route::resource('/slider', 'SliderController');
    Route::get('/orderan', 'OrderController@index')->name('orderan');
    Route::get('/pesanan-detail', 'OrderController@pesanan_detail')->name('pesanan.detail');
});
